from django.apps import AppConfig


class FilesConfig(AppConfig):
    name = "styleguide_example.files"
