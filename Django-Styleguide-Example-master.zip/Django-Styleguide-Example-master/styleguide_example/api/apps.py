from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = "styleguide_example.api"
