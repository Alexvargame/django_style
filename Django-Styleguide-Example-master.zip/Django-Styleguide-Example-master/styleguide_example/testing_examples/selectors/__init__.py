# flake8: noqa

from .schools import *
