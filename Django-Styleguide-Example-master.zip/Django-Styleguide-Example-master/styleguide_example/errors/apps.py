from django.apps import AppConfig


class ErrorsConfig(AppConfig):
    name = "styleguide_example.errors"
