from django.apps import AppConfig


class IntegrationsConfig(AppConfig):
    name = "styleguide_example.integrations"
